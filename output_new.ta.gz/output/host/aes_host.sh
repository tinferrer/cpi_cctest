
/home/optee/qemu-optee/toolchains/aarch32/bin/arm-linux-gnueabihf-gcc -c host.s -o host.o -I ~/qemu-optee/optee_client/out/export/include/
~/qemu-optee/toolchains/aarch32/bin/arm-linux-gnueabihf-gcc -I~/qemu-optee/my_test/host/headers/ host.o libtomcrypt.a ~/qemu-optee/optee_client/out/export/lib/libteec.so -o host


