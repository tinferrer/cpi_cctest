import unittest
from uavcan import node


# TODO


if __name__ == '__main__':
    unittest.main()
