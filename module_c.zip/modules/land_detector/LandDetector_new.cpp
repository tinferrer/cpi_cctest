/****************************************************************************
 *
 *   Copyright (c) 2013-2016 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name PX4 nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

/*
 * @file LandDetector.cpp
 *
 * @author Johan Jansen <jnsn.johan@gmail.com>
 * @author Julian Oes <julian@oes.ch>
 */

#include <px4_config.h>
#include <px4_defines.h>
#include <drivers/drv_hrt.h>
#include <float.h>

#include "LandDetector.h"
/**********************************************************************/
#include <systemlib/perf_counter.h>
#include <uORB/topics/LandDetector_log.h>


extern "C" {
/* OP-TEE TEE client API (built by optee_client) */
#include "tee_client_api.h"

/* To the the UUID (found the the TA's h-file(s)) */
#include "hello_world_ta.h"
}


static orb_advert_t LandDetector_log_pub;
struct perf_ctr_header {
	sq_entry_t		link;	/**< list linkage */
	enum perf_counter_type	type;	/**< counter type */
	const char		*name;	/**< counter name */
};
struct perf_ctr_interval {
	struct perf_ctr_header	hdr;
	uint64_t		event_count;
	uint64_t		time_event;
	uint64_t		time_first;
	uint64_t		time_last;
	uint32_t		time_least;
	uint32_t		time_most;
	float			mean;
	float			M2;
};
struct perf_ctr_elapsed {
	struct perf_ctr_header	hdr;
	uint64_t		event_count;
	uint64_t		time_start;
	uint64_t		time_total;
	uint32_t		time_least;
	uint32_t		time_most;
	float			mean;
	float			M2;
};

/**********************************************************************/


namespace land_detector
{


LandDetector::LandDetector() :
	_landDetectedPub(nullptr),
	_landDetected{0, false, false},
	_parameterSub(0),
	_state{},
	_freefall_hysteresis(false),
	_landed_hysteresis(true),
	_ground_contact_hysteresis(true),
	_taskShouldExit(false),
	_taskIsRunning(false),
	_total_flight_time{0},
	_takeoff_time{0},
	_work{}
{
	// Use Trigger time when transitioning from in-air (false) to landed (true) / ground contact (true).
	_landed_hysteresis.set_hysteresis_time_from(false, LAND_DETECTOR_TRIGGER_TIME_US);
	_ground_contact_hysteresis.set_hysteresis_time_from(false, GROUND_CONTACT_TRIGGER_TIME_US);
}

LandDetector::~LandDetector()
{
	
	work_cancel(HPWORK, &_work);
	_taskShouldExit = true;
}

int LandDetector::start()
{
	/******************************************************************/
	land_detector_cycle= perf_alloc(PC_ELAPSED, "land_detector_cycle");
	struct LandDetector_log_s mess;
	memset(&mess, 0, sizeof(mess));
	LandDetector_log_pub = orb_advertise(ORB_ID(LandDetector_log), &mess);
	/******************************************************************/
	_taskShouldExit = false;

	/* schedule a cycle to start things */
	work_queue(HPWORK, &_work, (worker_t)&LandDetector::_cycle_trampoline, this, 0);

	return 0;
}

void LandDetector::stop()
{
	/******************************************************************/
	perf_free(land_detector_cycle);
	/******************************************************************/
	_taskShouldExit = true;
	
}

void
LandDetector::_cycle_trampoline(void *arg)
{
	LandDetector *dev = reinterpret_cast<LandDetector *>(arg);

	dev->_cycle();
}


void LandDetector::_cycle()
{
	perf_begin(land_detector_cycle);
	//printf("INSIDE sensor update for block \n");
	if (!_taskIsRunning) {
		// Advertise the first land detected uORB.
		_landDetected.timestamp = hrt_absolute_time();

	/********************************************************************************************************************/

		//printf("INSIDE sensor update for block \n");
		TEEC_Result res;
		TEEC_Context ctx;
		TEEC_Session sess;
		TEEC_Operation op;
		TEEC_UUID uuid = TA_HELLO_WORLD_UUID;
		uint32_t err_origin;

		//struct vehicle_land_detected_s _landDetected_buf;

		//float air_temperature_celsius=0;

		//struct sensors_float_params fp;

		//fp.air_temperature_celsius_var =(_diff_pres.temperature > -300.0f) ? _diff_pres.temperature :
	//					(raw.baro_temp_celcius - PCB_TEMP_ESTIMATE_DEG);
		/*float yaw_input;
		double lat_input;			
		double lon_input;			
		float alt_input;
		float loiter_radius_input;		
		int8_t loiter_direction_input;	*/
					

		/*(fp).yaw_input=get_global_position()->yaw;
		(fp).lat_input = get_global_position()->lat;
		(fp).lon_input = get_global_position()->lon;
		(fp).alt_input = get_global_position()->alt;
		(fp).loiter_radius_input = get_loiter_radius();
		(fp).loiter_direction_input = 1;*/
		
		
//		printf("variable raw data before optee call: %f %f %f \n", (double) raw.accelerometer_m_s2[0], (double) raw.accelerometer_m_s2[1], (double) raw.accelerometer_m_s2[2]);

//printf("variable raw data to be updated with: %f %f %f \n", (double) _last_sensor_data[best_index].accelerometer_m_s2[0], (double) _last_sensor_data[best_index].accelerometer_m_s2[1], (double) _last_sensor_data[best_index].accelerometer_m_s2[2]);

		
		/* Initialize a context connecting us to the TEE */
		res = TEEC_InitializeContext(NULL, &ctx);
		//TEEC_InitializeContext(NULL, &ctx);
		if (res != TEEC_SUCCESS)
			printf("TEEC_InitializeContext failed with code 0x%x", res);

	/*
	 * Open a session to the "hello world" TA, the TA will print "hello
	 * world!" in the log when the session is created.
	 */
		res = TEEC_OpenSession(&ctx, &sess, &uuid,TEEC_LOGIN_PUBLIC, NULL, NULL, &err_origin);
		//TEEC_OpenSession(&ctx, &sess, &uuid,
		//	       TEEC_LOGIN_PUBLIC, NULL, NULL, &err_origin);
		if (res != TEEC_SUCCESS)
			printf("TEEC_Opensession failed with code 0x%x origin 0x%x",res, err_origin);

			/*
	 * Execute a function in the TA by invoking it, in this case
	 * we're incrementing a number.
	 *
	 * The value of command ID part and how the parameters are
	 * interpreted is part of the interface provided by the TA.
	 */

	/* Clear the TEEC_Operation struct */
	
	memset(&op, 0, sizeof(op));
	
	/*
	 * Prepare the argument. Pass a value in the first parameter,
	 * the remaining three parameters are unused.
	 */
	/*op.paramTypes = TEEC_PARAM_TYPES(TEEC_VALUE_INOUT, TEEC_NONE,
					 TEEC_NONE, TEEC_NONE);*/


	op.paramTypes = TEEC_PARAM_TYPES(TEEC_MEMREF_TEMP_INOUT, TEEC_MEMREF_TEMP_INOUT, TEEC_VALUE_INOUT, TEEC_VALUE_INOUT);
	
	/*rep->previous.yaw = get_global_position()->yaw;
	rep->previous.lat = get_global_position()->lat;
	rep->previous.lon = get_global_position()->lon;
	rep->previous.alt = get_global_position()->alt;*/

	op.params[0].tmpref.buffer= &_landDetected;
	op.params[0].tmpref.size=  sizeof (struct vehicle_land_detected_s);

	//op.params[1].tmpref.buffer= &_last_sensor_data;
	//op.params[1].tmpref.size=  sizeof ( struct sensor_combined_s);
	
	//op.params[2].value.a=best_index; 	
	

	//struct position_setpoint_triplet_s *rep1= (struct position_setpoint_triplet_s*) op.params[0].tmpref.buffer;	
	
	//printf("land detector data buffer before optee call: %s %s %s \n",  _landDetected.landed, _landDetected.freefall, _landDetected.ground_contact);

//	printf("position_setpoint_triplet data points checking pointer buffer sanity before optee call: %f %f %f %f %f %d\n",  (double) (*rep).previous.yaw, (*rep).previous.lat, (*rep).previous.lon, (double) (*rep).previous.alt, (double) (*rep).current.loiter_radius, (*rep).current.loiter_direction);

	

	/*op.params[1].value.a = (uint32_t) yaw_input;
	op.params[1].value.b = (uint32_t) lat_input;
	
	op.params[2].value.a = (uint32_t) lon_input;
	op.params[2].value.b = (uint32_t) alt_input;	

	op.params[3].value.a = (uint32_t) loiter_radius_input;
	op.params[3].value.b = (int8_t) loiter_direction_input;*/
	
	/*op.params[1].value.a = 1;
	op.params[1].value.b = 2;
	
	op.params[2].value.a = 3;
	op.params[2].value.b = 4;	

	op.params[3].value.a = 5;
	op.params[3].value.b = 6;*/


	res = TEEC_InvokeCommand(&sess, TA_HELLO_WORLD_CMD_INC_VALUE, &op, &err_origin);
	//TEEC_InvokeCommand(&sess, TA_HELLO_WORLD_CMD_INC_VALUE, &op,
	//			 &err_origin);
	if (res != TEEC_SUCCESS)
		printf("TEEC_InvokeCommand failed with code 0x%x origin 0x%x",res, err_origin);	

	//printf("land detector data buffer before optee call:  %s %s %s \n",  _landDetected.landed, _landDetected.freefall, _landDetected.ground_contact);

//printf("variable raw data after optee call: %f %f %f \n", (double) raw.accelerometer_m_s2[0], (double) raw.accelerometer_m_s2[1], (double) raw.accelerometer_m_s2[2]);

	//printf("variable raw data after optee call: %f \n", (double)air_temperature_celsius);

	//printf("position_setpoint_triplet data points after optee call: %f %f %f %f %f %d \n", (double) rep->previous.yaw, rep->previous.lat, rep->previous.lon, (double) rep->previous.alt, (double)  rep->current.loiter_radius,  rep->current.loiter_direction);


	//printf("param values after optee call: %d %d %d %d %d %d \n", op.params[1].value.a, op.params[1].value.b, op.params[2].value.a, op.params[2].value.b, op.params[3].value.a,  op.params[3].value.b);
	
	//air_temperature_celsius=op.params[2].value.a;
	
	TEEC_CloseSession(&sess);
	
	TEEC_FinalizeContext(&ctx);
	//printf("exiting optee code block inside TAKE OFF if else block \n");


/*********************************************************************************************************************/

		/*_landDetected.freefall = false;
		_landDetected.landed = false;
		_landDetected.ground_contact = false;*/
		_p_total_flight_time_high = param_find("LND_FLIGHT_T_HI");
		_p_total_flight_time_low = param_find("LND_FLIGHT_T_LO");

		// Initialize uORB topics.
		_initialize_topics();

		_check_params(true);

		// Task is now running, keep doing so until we need to stop.
		_taskIsRunning = true;
	}

	_check_params(false);

	_update_topics();

	hrt_abstime now = hrt_absolute_time();

	_update_state();

	float alt_max_prev = _altitude_max;
	_altitude_max = _get_max_altitude();

	bool freefallDetected = (_state == LandDetectionState::FREEFALL);
	bool landDetected = (_state == LandDetectionState::LANDED);
	bool ground_contactDetected = (_state == LandDetectionState::GROUND_CONTACT);

	// Only publish very first time or when the result has changed.
	if ((_landDetectedPub == nullptr) ||
	    (_landDetected.freefall != freefallDetected) ||
	    (_landDetected.landed != landDetected) ||
	    (_landDetected.ground_contact != ground_contactDetected) ||
	    (fabsf(_landDetected.alt_max - alt_max_prev) > FLT_EPSILON)) {

		if (!landDetected && _landDetected.landed) {
			// We did take off
			_takeoff_time = now;

		} else if (_takeoff_time != 0 && landDetected && !_landDetected.landed) {
			// We landed
			_total_flight_time += now - _takeoff_time;
			_takeoff_time = 0;
			int32_t flight_time = (_total_flight_time >> 32) & 0xffffffff;
			param_set_no_notification(_p_total_flight_time_high, &flight_time);
			flight_time = _total_flight_time & 0xffffffff;
			param_set_no_notification(_p_total_flight_time_low, &flight_time);
			param_notify_changes(); // this will notify the commander, who will save the params
		}

		_landDetected.timestamp = hrt_absolute_time();
		_landDetected.freefall = (_state == LandDetectionState::FREEFALL);
		_landDetected.landed = (_state == LandDetectionState::LANDED);
		_landDetected.ground_contact = (_state == LandDetectionState::GROUND_CONTACT);
		_landDetected.alt_max = _altitude_max;

		int instance;
		orb_publish_auto(ORB_ID(vehicle_land_detected), &_landDetectedPub, &_landDetected,
				 &instance, ORB_PRIO_DEFAULT);
	}

	if (!_taskShouldExit) {

		// Schedule next cycle.
		work_queue(HPWORK, &_work, (worker_t)&LandDetector::_cycle_trampoline, this,
			   USEC2TICK(1000000 / LAND_DETECTOR_UPDATE_RATE_HZ));

	} else {
		_taskIsRunning = false;
	}
	/******************************************************************/
	struct LandDetector_log_s message;
	message.timestamp = hrt_absolute_time();
	struct perf_ctr_elapsed *publish_perf_count = (struct perf_ctr_elapsed *)land_detector_cycle;
	message.elapsed = message.timestamp - publish_perf_count->time_start;
	/******************************************************************/
	perf_end(land_detector_cycle);
	/******************************************************************/
	message.max_time = publish_perf_count->time_most;
	message.min_time = publish_perf_count->time_least;
	orb_publish(ORB_ID(LandDetector_log), LandDetector_log_pub, &message);
	/******************************************************************/
}
void LandDetector::_check_params(const bool force)
{
	bool updated;
	parameter_update_s paramUpdate;

	orb_check(_parameterSub, &updated);

	if (updated) {
		orb_copy(ORB_ID(parameter_update), _parameterSub, &paramUpdate);
	}

	if (updated || force) {
		_update_params();
		int32_t flight_time;
		param_get(_p_total_flight_time_high, &flight_time);
		_total_flight_time = ((uint64_t)flight_time) << 32;
		param_get(_p_total_flight_time_low, &flight_time);
		_total_flight_time |= flight_time;
	}
}





void LandDetector::_update_state()
{
	/* ground contact and landed can be true simultaneously but only one state can be true at a particular time
	 * with higher priority for landed */
	bool freefall = _get_freefall_state();
	bool landed = _get_landed_state();
	bool groundContact = (landed || _get_ground_contact_state());

	_freefall_hysteresis.set_state_and_update(freefall);
	_landed_hysteresis.set_state_and_update(landed);
	_ground_contact_hysteresis.set_state_and_update(groundContact);

	if (_freefall_hysteresis.get_state()) {
		_state = LandDetectionState::FREEFALL;

	} else if (_landed_hysteresis.get_state()) {
		_state = LandDetectionState::LANDED;

	} else if (_ground_contact_hysteresis.get_state()) {
		_state = LandDetectionState::GROUND_CONTACT;

	} else {
		_state = LandDetectionState::FLYING;
	}
}

bool LandDetector::_orb_update(const struct orb_metadata *meta, int handle, void *buffer)
{
	bool newData = false;

	// check if there is new data to grab
	if (orb_check(handle, &newData) != OK) {
		return false;
	}

	if (!newData) {
		return false;
	}

	if (orb_copy(meta, handle, buffer) != OK) {
		return false;
	}

	return true;
}


} // namespace land_detector
