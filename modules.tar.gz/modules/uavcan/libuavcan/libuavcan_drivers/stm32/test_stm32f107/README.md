UAVCAN test project for STM32
-----------------------------

Please checkout/symlink https://github.com/Zubax/zubax_chibios, branch `stable_v1`, into subdirectory `zubax_chibios`; then follow instructions in `zubax_chibios/README.md`.
