/****************************************************************************
 *
 *   Copyright (c) 2012-2015 PX4 Development Team. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in
 *    the documentation and/or other materials provided with the
 *    distribution.
 * 3. Neither the name PX4 nor the names of its contributors may be
 *    used to endorse or promote products derived from this software
 *    without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 * INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS
 * OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
 * AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 * ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.
 *
 ****************************************************************************/

/**
 * @file px4_daemon_app.c
 * daemon application example for PX4 autopilot
 *
 * @author Example User <mail@example.com>
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <px4_config.h>
#include <px4_tasks.h>

#include <systemlib/systemlib.h>
#include <systemlib/err.h>

#include "tee_client_api.h"
#include "module_murderer_ta.h"

static bool thread_should_exit = false;		/**< daemon exit flag */
static bool thread_running = false;		/**< daemon status flag */
static int daemon_task;				/**< Handle of daemon task / thread */

/**
 * daemon management function.
 */
__EXPORT int tanmaya_module_murderer_main(int argc, char *argv[]);

/**
 * Mainloop of daemon.
 */
int tanmaya_module_murderer_thread_main(int argc, char *argv[]);

/**
 * Print the correct usage.
 */
static void usage(const char *reason);

static void
usage(const char *reason)
{
	if (reason) {
		warnx("%s\n", reason);
	}

	warnx("usage: daemon {start|stop|status} [-p <additional params>]\n\n");
}

/**
 * The daemon app only briefly exists to start
 * the background job. The stack size assigned in the
 * Makefile does only apply to this management task.
 *
 * The actual stack size should be set in the call
 * to task_create().
 */
int tanmaya_module_murderer_main(int argc, char *argv[])
{
	
	
	if (argc < 2) {
		usage("missing command");
		return 1;
	}

	if (!strcmp(argv[1], "start")) {

		if (thread_running) {
			warnx("daemon already running\n");
			/* this is not an error */
			return 0;
		}

		thread_should_exit = false;
		daemon_task = px4_task_spawn_cmd("tanmaya_module_murderer",
						 SCHED_DEFAULT,
						 SCHED_PRIORITY_MAX - 4,
						 2000,
						 tanmaya_module_murderer_thread_main,
						 (argv) ? (char *const *)&argv[2] : (char *const *)NULL);
		return 0;
	}

	if (!strcmp(argv[1], "stop")) {
		thread_should_exit = true;
		return 0;
	}

	if (!strcmp(argv[1], "status")) {
		if (thread_running) {
			warnx("\trunning\n");

		} else {
			warnx("\tnot started\n");
		}

		return 0;
	}

	usage("unrecognized command");
	return 1;
}

int tanmaya_module_murderer_thread_main(int argc, char *argv[])
{

	TEEC_Result res2;
	TEEC_Context ctx;
	TEEC_Session sess;
	TEEC_Operation op;
	TEEC_UUID uuid = MODULE_MURDERER_TA_UUID;
	uint32_t err_origin;
	warnx("[daemon] starting\n");

	thread_running = true;

	while (!thread_should_exit) {
		int i;
		for (i=0; i< 4; i++){
		res2 = TEEC_InitializeContext(NULL, &ctx);
		if (res2 != TEEC_SUCCESS)
			printf("Murderer: TEEC_InitializeContext failed with code 0x%x\n", res2);
		res2 = TEEC_OpenSession(&ctx, &sess, &uuid,
			       TEEC_LOGIN_PUBLIC, NULL, NULL, &err_origin);
		if (res2 != TEEC_SUCCESS)
			printf("Murderer: TEEC_Opensession failed with code 0x%x origin 0x%x\n",
				res2, err_origin);
				
		memset(&op, 0, sizeof(op));	
	 
		op.paramTypes = TEEC_PARAM_TYPES(TEEC_NONE,TEEC_NONE,TEEC_NONE,TEEC_NONE);
						   
		//printf("Murderer: Entering TA");
		res2 = TEEC_InvokeCommand(&sess, MODULE_MURDERER_TA_RUN, &op,
				 &err_origin);
		if (res2 != TEEC_SUCCESS)
			printf("Murderer: TEEC_InvokeCommand failed with code 0x%x origin 0x%x\n",
				res2, err_origin);
		//printf("Murderer: Exited TA");
		TEEC_CloseSession(&sess);
		TEEC_FinalizeContext(&ctx);
		}
		//warnx("Hello daemon!\n");
		//sleep(10);
	}

	warnx("[daemon] exiting.\n");

	thread_running = false;

	return 0;
}
