import pandas as pd


class Qlearning:
    _qmatrix = None
    _learn_rate = None
    _discount_factor = None
    _w = None
    def __init__(self,
                 possible_states,
                 possible_actions,
                 initial_reward,
                 learning_rate,
                 discount_factor):
        """
        Initialise the q learning class with an initial matrix and the parameters for learning.

        :param possible_states: list of states the agent can be in
        :param possible_actions: list of actions the agent can perform
        :param initial_reward: the initial Q-values to be used in the matrix
        :param learning_rate: the learning rate used for Q-learning
        :param discount_factor: the discount factor used for Q-learning
        """
        # Initialize the matrix with Q-values
        init_data = [[float(initial_reward) for _ in possible_states]
                     for _ in possible_actions]
        self._qmatrix = pd.DataFrame(data=init_data,
                                     index=possible_actions,
                                     columns=possible_states)

        # Save the parameters
        self._learn_rate = learning_rate
        self._discount_factor = discount_factor
	self._w = 1.0
    def get_best_action(self, state):
        """
        Retrieve the action resulting in the highest Q-value for a given state.

        :param state: the state for which to determine the best action
        :return: the best action from the given state
        """
        # Return the action (index) with maximum Q-value
        return self._qmatrix[[state]].idxmax().iloc[0]

    def update_model(self, state, action, next_state, reward):
        """
        Update the Q-values for a given observation.

        :param state: The state the observation started in
        :param action: The action taken from that state
        :param reward: The reward retrieved from taking action from state
        :param next_state: The resulting next state of taking action from state
        """
        # Update q_value for a state-action pair Q(s,a):
        q_sa = self._qmatrix.ix[action, state]
        max_q_sa_next = self._qmatrix.ix[self.get_best_action(next_state), next_state]
        r = reward
        #alpha = self._learn_rate
        alpha = 1.0/(1.0+self._w)
        self._w = self._w+1.0
        print self._w
        gamma = self._discount_factor

        # Do the computation
        new_q_sa = q_sa + alpha * (r + gamma * max_q_sa_next - q_sa)
        self._qmatrix.set_value(action, state, new_q_sa)
        print new_q_sa
       #print self._qmatrix,"\n", sum(self._qmatrix.ix[1,1])

qlearn = Qlearning([1,2], [1,2], 0, 0.1, 0.9)

#  st   at   st+1  rt
#   1    2    2    0
#   2    1    1    2
#   1    2    1    3
#   1    2    1    3
#   1    1    1    1

#   1    1    2    1
#   2    1    1    2
#   1    1    1    1
#   1    1    1    1
#   1    2    1    3

#   1    1    1    1
#   1    1    1    1
#   1    1    1    1
#   1    1    2    1
#   2    2    2    0

#   2    1    1    2
#   1    2    1    3
#   1    1    1    1
#   1    1    2    1
#   2    2    2    0

def test():
        
	qlearn.update_model(1, 2, 2, 0)
	qlearn.update_model(2, 1, 1, 2)
	qlearn.update_model(1, 2, 1, 3)
	qlearn.update_model(1, 2, 1, 3)
	qlearn.update_model(1, 1, 1, 1)


	qlearn.update_model(1, 1, 2, 1)
	qlearn.update_model(2, 1, 1, 2)
	qlearn.update_model(1, 1, 1, 1)
	qlearn.update_model(1, 1, 1, 1)
	qlearn.update_model(1, 2, 1, 3)


	qlearn.update_model(1, 1, 1, 1)
	qlearn.update_model(1, 1, 1, 1)
	qlearn.update_model(1, 1, 1, 1)
	qlearn.update_model(1, 1, 2, 1)
	qlearn.update_model(2, 2, 2, 0)


	qlearn.update_model(2, 1, 1, 2)
	qlearn.update_model(1, 2, 1, 3)
	qlearn.update_model(1, 1, 1, 1)
	qlearn.update_model(1, 1, 2, 1)
	qlearn.update_model(2, 2, 2, 0)

count = 1000
while (count > 0):
	test()
	count=count-1
